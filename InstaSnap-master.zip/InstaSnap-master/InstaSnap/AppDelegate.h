//
//  AppDelegate.h
//  InstaSnap
//
//  Created by Anis Kadri on 1/22/16.
//  Copyright © 2016 Anis Kadri. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

